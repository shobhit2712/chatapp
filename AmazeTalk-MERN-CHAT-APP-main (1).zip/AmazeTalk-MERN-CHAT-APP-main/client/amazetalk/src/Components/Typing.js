import React from 'react'
export default function Typing() {
  return (
    <div className="other-message-container" >
      <div className="other-text-content">
        <p style={{color:'black'}}>typing....</p>
      </div>
    </div>
  )
}
